
import en from './en.js'; 
import es from './es.js'; 
import pt from './pt.js'; 
import id from './id.js';
import ar from './ar.js';

export {en, es, pt, id, ar};
